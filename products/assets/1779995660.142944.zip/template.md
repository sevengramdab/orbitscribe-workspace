# **Notion Templates for Small Businesses**

## Setup Instructions

### Step 1: Duplicate the Template
Duplicate this template to create a new page in your Notion workspace.

### Step 2: Customize Your Template
Rename the template and add your company's logo to the top of the page.

## **Company Information**
| Field | Description |
| --- | --- |
| Company Name | [Insert company name] |
| Address | [Insert address] |
| Phone Number | [Insert phone number] |
| Email | [Insert email] |
| Website | [Insert website] |

## **Team Members**
### Team Leaders
- [Name]: [Position]
- [Name]: [Position]

### Department Heads
- [Department]: [Head's Name]
  - [Sub-Departments]: [Sub-Department Heads' Names]

### Employees
| Name | Position | Department |
| --- | --- | --- |
|- | - | - |

## **Projects**
### Current Projects
| Project Name | Status | Deadline | Team Members |
| --- | --- | --- | --- |
|- | - | - | - |

### Completed Projects
| Project Name | Completion Date | Team Members |
| --- | --- | --- |
|- | - | - |

## **Tasks**
### Today's Tasks
- [Task 1]: [Status]
- [Task 2]: [Status]

### Upcoming Tasks
| Task | Due Date | Status |
| --- | --- | --- |
|- | - | - |

## **Meetings**
### Scheduled Meetings
| Meeting Name | Date | Time | Location |
| --- | --- | --- | --- |
|- | - | - | - |

### Past Meetings
| Meeting Name | Date | Notes |
| --- | --- | --- |
|- | - | - |

## **Documents**
### Company Policies
- [Policy 1]: [Link]
- [Policy 2]: [Link]

### Employee Handbooks
- [Handbook 1]: [Link]
- [Handbook 2]: [Link]

### Contracts
- [Contract 1]: [Link]
- [Contract 2]: [Link]

## **Settings**
### Notifications
- [Notification 1]: [Setting]
- [Notification 2]: [Setting]
